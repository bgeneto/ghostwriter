# Ghostwriter · ícones para Tauri 2

## Instalação no projeto desktop

Copie a pasta `src-tauri/icons/` deste ZIP para o seu projeto, mesclando com a pasta existente. Os arquivos padrão do template Tauri podem ser substituídos. Mantenha as demais opções do seu `src-tauri/tauri.conf.json` e confira se `bundle.icon` aponta para os arquivos abaixo.

```json
{
  "bundle": {
    "icon": [
      "icons/32x32.png",
      "icons/128x128.png",
      "icons/128x128@2x.png",
      "icons/512x512.png",
      "icons/icon.icns",
      "icons/icon.ico"
    ]
  }
}
```

- `app-icon.png` é a matriz RGBA de **1024 × 1024 px**.
- `src-tauri/icons/512x512.png` é a versão **512 × 512 px** com transparência, equivalente a 256 × 256 pontos em escala 2×. `icon.png` contém a mesma imagem, com o nome padrão do Tauri.
- `128x128@2x.png` tem 256 × 256 pixels físicos. O `icon.icns` inclui representações Retina, e o `icon.ico` reúne múltiplos tamanhos, de 16 até 256 px.
- `Square*Logo.png` e `StoreLogo.png` são as variantes AppX geradas pelo CLI.

## Se o projeto também tiver Android ou iOS

O ZIP inclui as variantes móveis geradas pelo CLI. Elas não são necessárias para desktop. Se o projeto móvel já estiver inicializado:

- Mescle o conteúdo de `src-tauri/icons/android/` com `src-tauri/gen/android/app/src/main/res/`.
- Copie os PNGs de `src-tauri/icons/ios/` para `src-tauri/gen/apple/Assets.xcassets/AppIcon.appiconset/`, preservando o `Contents.json` do projeto. `AppIcon-512@2x.png` tem 1024 × 1024 px e fundo opaco.

Para regenerar a partir da matriz, coloque `app-icon.png` na raiz do projeto e rode:

```sh
npm run tauri icon -- app-icon.png --ios-color '#161532'
```

[Documentação oficial de ícones do Tauri 2](https://v2.tauri.app/develop/icons/)
